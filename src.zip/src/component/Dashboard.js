import React, { useEffect } from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useSelector } from 'react-redux';

const Dashboard = () => {
  const user = useSelector((state) => state.authLogin);
  const navigate = useNavigate();

  useEffect(() => {
    console.log(user);
  }, [user]);

  const handleLogout = () => {
    localStorage.removeItem('username');
    navigate('/login');
  };

  return (
    <div className="d-flex">
      <div className="bg-light p-3 " style={{ width: '250px', height: '100vh' }}>
        <h4 >Dashboard</h4>
        <ul className="nav flex-column">
          <li className="nav-item">
            <Link className="nav-link" to="/dashboard/listdashboard">Dashboard</Link>
          </li>
          <div className="btn-group">
            <button
              type="button"
              className="btn btn-primary dropdown-toggle"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              User Management
            </button>
            <ul className="dropdown-menu">
              <li>
                <Link className="dropdown-item" to="/profile">Admin</Link>
              </li>
              <li>
                <Link className="dropdown-item" to="/settings">Employee</Link>
              </li>
              <li>
                <Link className="dropdown-item" to="/settings">Dealer</Link>
              </li>
            </ul>
          </div>
          <li className="nav-item">
            <Link className="nav-link" to="/settings">Leads</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/login">Login Page</Link>
          </li>
          <li>
                <button className="dropdown-item nav-link" onClick={handleLogout}>Logout</button>
              </li>
        </ul>
      </div>

      <div className="flex-grow-1 p-3">
        <Outlet />
      </div>
    </div>
  );
};

export default Dashboard;
