import React, { useEffect, useState } from 'react';
import { Users } from './axios/Service';
import { useSelector } from 'react-redux';

export default function ListDashboard() {
  const [people, setPeople] = useState([]);
  const datass=useSelector((state)=>state.authLogin)
  const[array,setArray]=useState([]);
  const handle=()=>{
  let formdata=new FormData();
  formdata.append('token',datass.token);
   Users(formdata)
   .then((response)=>{
    console.log("API Response:" , response.data);
    setPeople(response.data.data);
   })
  }
//   useEffect(() => {
    
//     const token = localStorage.getItem('username');
  
//     if (token) {
//       let formdata = new FormData();
//       console.log(token);
//       formdata.append('token', token);
//      console.log(formdata);
//       Users(formdata).then((response) => {
//         setPeople(response.data);
//         console.log(response.data);
//       }).catch((error) => {
//         console.error('Error fetching data:', error);
//       });
//     } else {
//       console.warn('No token found in localStorage');
//     }
//   }, []);


useEffect(()=>{
  handle();
},[datass.token])
  
  return (
    <div>
    <h1>Welcome</h1>
    <div className="row">
      {people.map((item, index) => (
        <div className="col-lg-3 g-5" key={index}>
          <div className="card bg-warning" >
           <strong> <p>{item.displayName}</p></strong>
            <p>{item.type}</p>
            <p>{item.leads.displayName} {":"+item.leads.value}</p>
            <p>{item.over_due.displayName} {":"+item.over_due.value}</p>
          </div>
        </div>
      ))}
    </div>
  </div>
  );
}
