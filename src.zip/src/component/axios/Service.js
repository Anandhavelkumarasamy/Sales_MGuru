
import instance from "./Axios";

export const signin=(login)=>{
    return instance.post("/login",login)
}
export const Users=(token)=>{
    return instance.post("/dashboard/all_data_count",token);
}