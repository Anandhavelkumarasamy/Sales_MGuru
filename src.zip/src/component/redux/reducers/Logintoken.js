import { createSlice } from "@reduxjs/toolkit"

// import { createSlice } from "@reduxjs/toolkit";
const initialState={
    token:'',
}
// const logintoken=createSlice({
//     name:'authtoken',
//     initialState,
//     reducers:{
//         handleStorage:(state,action)=>{
//             state.token=action.payload;
//         }
//     }
// })
// export const{handleStorage}=logintoken.actions;
// export default logintoken.reducer;


const {actions,reducer} = createSlice({
    name:"authLogin",
    initialState,
    reducers:{
        handleStorage:(state,action) => {
            state.token = action.payload
        }
    }
})

export const {handleStorage} = actions

export default reducer