import React, { useState } from 'react';
import loginimage from '../component/assests/4957136.jpg'
import { useNavigate,Link } from 'react-router-dom';
import classes from './Login.module.css';
import { signin } from './axios/Service';
import loginbg from './assests/3334896.jpg';

import { useSelector,useDispatch } from 'react-redux';
import { handleStorage } from './redux/reducers/Logintoken';

function Login() {

    const [username,setUserName]=useState("");
    const [password,setPassword]=useState("");
const navigate=useNavigate();
    var sha1=require('sha1');
    
    const dispatch=useDispatch();
    

   // const userdetails={username:username,password:password}


   

  const handleSubmit=(e)=>{
    e.preventDefault();
   
     let formdata = new FormData();
 formdata.append("userName",username);
 formdata.append('password',password);
 formdata.append('device_type','3');
 formdata.append('authcode',sha1("lkjfjIHJL@fdj385!jhg"+username));
 signin(formdata).then((response)=>{
  localStorage.setItem("username",JSON.stringify(response.data.token))
  dispatch(handleStorage(response.data.token))
  console.log(response.data.token);
console.log('verified');
navigate('/dashboard/listdashboard');

 
 })
    .catch((error)=>{
      console.log("error");
})}

  return (
    <div className={classes.loginbg}>
  
    <div className={`container bg-white rounded-5 p-5 ${classes.container}`}>
      <div className="row">
        <div className="col-12 text-center">
          <h3><strong>Welcome!!</strong><hr /></h3>
        </div>
        <div className={`col-lg-6 col-md-6 d-flex align-items-center justify-content-center ${classes.container2}`}>
          <img src={loginimage} alt="YourImage" className="img-fluid rounded-5" />
        </div>
  
        <div className="col-lg-6 col-md-6 d-flex align-items-center justify-content-center">
          <div className="bg-light p-5 w-100 rounded-5">
            <h2 className="text-center">Login<hr /></h2>
            <form className="text-center" onSubmit={handleSubmit}>
              <input
                type="text"
                name="username"
                placeholder="Username"
                required
                className="form-control my-3"
                onChange={(event) => { setUserName(event.target.value) }}
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                required
                className="form-control my-3"
                onChange={(event) => { setPassword(event.target.value) }}
              />
              <input
                type="submit"
                value="Submit"
                className="btn btn-success rounded my-2"
              />
              <div className="form-check text-start my-3">
                <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                <label className="form-check-label" htmlFor="flexCheckDefault">
                  Remember me
                </label>
              </div>
              <a href="#s" className="text-warning text-start d-block">Forgot Password?</a>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  );
}

export default Login;
