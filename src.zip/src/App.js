import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './component/Login';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { AuthPrivate, HomePrivate } from './component/router/Privaterouter';
import Dashboard from './component/Dashboard';
import ListDashboard from './component/ListDashboard';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { handleStorage } from './component/redux/reducers/Logintoken';

function App() {

  const router=createBrowserRouter([{
  path:"/",
  element:<AuthPrivate/>,
  children:[{
    path:'login',
    element:<Login/>,
  }]
  },
  { path:"/",
    element:<HomePrivate/>,
    children:[{
      path:'dashboard',
      element:<Dashboard/>,
      children:[{
        path:'listdashboard',
        element:<ListDashboard/>
      }]
    }
  ]
    }  
])
const dispatch=useDispatch();
const token=localStorage.getItem("username")
useEffect(()=>{
  console.log(localStorage.getItem("username"),"token",token);
  dispatch(handleStorage(localStorage.getItem("username")))
// if(localStorage.getItem("username")!==""){
  
// }
},[localStorage.getItem("username")])
  return (
    <div className="App">
      <RouterProvider router={router}/>
    </div>
  );
}

export default App;
